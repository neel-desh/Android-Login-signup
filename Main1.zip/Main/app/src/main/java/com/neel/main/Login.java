package com.neel.main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    EditText email,password;
    Button loginbtn;
    TextView gotoregbtn,forgotpass,phonelogin;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firebaseAuth = FirebaseAuth.getInstance();


        email = findViewById(R.id.newpass);
        password = findViewById(R.id.password);
        loginbtn = findViewById(R.id.btnLogin);
        gotoregbtn = findViewById(R.id.gotoRegister);
        forgotpass = findViewById(R.id.forgotpass);
        phonelogin = findViewById(R.id.phonelogin);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cemail = email.getText().toString().trim();
                String cpass = password.getText().toString().trim();
                if(TextUtils.isEmpty(cemail)){

                    email.setError("Enter Email");
                    return;
                }
                if(TextUtils.isEmpty(cpass)){

                    email.setError("Enter Password");
                    return;
                }

            firebaseAuth.signInWithEmailAndPassword(cemail,cpass)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                            if(firebaseAuth.getCurrentUser().isEmailVerified()) {
                                Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            }else{
                                Toast.makeText(getApplicationContext(),"Please Verify your email",Toast.LENGTH_LONG).show();

                            }
                    }else{

                        Toast.makeText(getApplicationContext(),"Error"+task.getException().getMessage(),Toast.LENGTH_LONG).show();


                    }
                }
            });


            }
        });

        gotoregbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Register.class));

            }
        });

        forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),ForgetPass.class));
            }
        });
        phonelogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), OtpLogSig.class));

            }
        });
    }

}
