package com.neel.main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ResetPass extends AppCompatActivity {
FirebaseAuth firebaseAuth;
EditText oldpass,newpass,confirmpass;
Button reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_pass);

        firebaseAuth = FirebaseAuth.getInstance();
       // final FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
       // oldpass = findViewById(R.id.oldpass);
        newpass = findViewById(R.id.newpass);
       // confirmpass = findViewById(R.id.confirmpass);
        reset = findViewById(R.id.resetpassbtn);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(TextUtils.isEmpty(newpass.getText().toString())){

                    newpass.setError("Enter New pass");
                }


                    firebaseAuth.getCurrentUser().updatePassword(newpass.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(getApplicationContext(),"Password Updated Successfully",Toast.LENGTH_LONG).show();
firebaseAuth.signOut();
startActivity(new Intent(getApplicationContext(),Login.class));
                            }else{

                                Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_LONG).show();

                            }

                        }
                    });




            }
        });

    }
}
